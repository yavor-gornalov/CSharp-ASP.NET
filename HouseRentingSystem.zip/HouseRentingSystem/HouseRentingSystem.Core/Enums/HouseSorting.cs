﻿namespace HouseRentingSystem.Core.Enums;

public enum HouseSorting
{
	Newest = 0,
	Price = 1,
	NotRentedFirst = 2,
}
