﻿namespace HouseRentingSystem.Core.Contracts.House;

public interface IHouseModel
{
    public string Title { get; }

    public string Address { get; }
}
