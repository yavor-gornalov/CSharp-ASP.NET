﻿namespace HouseRentingSystem.Core.Models.Statistics;

public class StatisticServiceModel
{
	public int TotalHouses { get; set; }

	public int TotalRents { get; set; }
}
